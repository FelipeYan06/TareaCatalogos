package controller;

import views.Principal;

/**
 *
 * @author Felipe Yan
 */
public class Main {

    public static Principal principal = new Principal();
    
    public static void main(String[] args) {

        principal.setVisible(true);
        principal.setLocationRelativeTo(null);

    }
}
